from setuptools import setup

setup(name='park',
      version='0.0.1',
      install_requires=['numpy', 'wget', 'networkx', 'gym', 'dill', 'pycapnp', 'pandas']
)
